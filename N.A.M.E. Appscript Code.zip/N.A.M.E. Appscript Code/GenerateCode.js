function fetchCampaignLinks() {
  var spreadsheetId = '1pck0zyibpzJ-_0SBGa0-LQ0L7pI9-9eSUzOnXo3wWGY';
  var spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  var sheet = spreadsheet.getSheetByName('Customer');
  
  if (!sheet) {
    Logger.log("Sheet 'Customer' not found.");
    return;
  }
  
  var data = sheet.getDataRange().getValues();
  var apiKey = 'AIzaSyD5d2D6SiE4Gg_Yybh6L6K-2W0cqGzy9js';
  var cx = '95a1e35fa817b4b2c';  // Use your CSE ID
  
  var baseUrl = 'https://www.googleapis.com/customsearch/v1?';
  var startRow = 2;
  
  // Set the column headers
  sheet.getRange(1, 8).setValue('myGroser link');
  sheet.getRange(1, 9).setValue('jayaGrocer link');
  sheet.getRange(1, 10).setValue('lotuss link');
  sheet.getRange(1, 11).setValue('Shopee link');
  sheet.getRange(1, 12).setValue('Lazada link');
  
  for (var i = 1; i < data.length; i++) {
    var preferences = data[i][5];  // Preferences column (adjust if needed)
    var preferenceList = preferences.split(',').map(function(pref) { return pref.trim(); });
    
    var myGroserLinks = [];
    var jayaGrocerLinks = [];
    var lotussLinks = [];
    var shopeeLinks = [];
    var lazadaLinks = [];
    
    for (var j = 0; j < preferenceList.length; j++) {
      var query = encodeURIComponent(preferenceList[j]);
      var url = baseUrl + 'q=' + query + '&key=' + apiKey + '&cx=' + cx + '&num=10&safe=high';
      
      try {
        var response = UrlFetchApp.fetch(url);
        var json = JSON.parse(response.getContentText());
        
        Logger.log(JSON.stringify(json, null, 2));
        
        if (json.items && json.items.length > 0) {
          var links = extractRelevantLinks(json.items);
          
          if (links) {
            if (links.myGroserLink) myGroserLinks.push(links.myGroserLink);
            if (links.jayaGrocerLink) jayaGrocerLinks.push(links.jayaGrocerLink);
            if (links.lotussLink) lotussLinks.push(links.lotussLink);
            
            var shopeeLink = generateShopeeLink(preferenceList[j]);
            var lazadaLink = generateLazadaLink(preferenceList[j]);
            if (shopeeLink) shopeeLinks.push(shopeeLink);
            if (lazadaLink) lazadaLinks.push(lazadaLink);
          }
        } else {
          Logger.log("No items found for query: " + query);
        }
      } catch (e) {
        Logger.log("Error fetching or parsing data for query: " + query);
        Logger.log(e.toString());
      }
    }
    
    // Combine links into a single cell
    updateCampaignTracker(sheet, startRow, {
      myGroserLink: myGroserLinks.join(' , '),
      jayaGrocerLink: jayaGrocerLinks.join(' , '),
      lotussLink: lotussLinks.join(' , '),
      shopeeLink: shopeeLinks.join(' , '),
      lazadaLink: lazadaLinks.join(' , ')
    });
    
    startRow++;
  }
}

function extractRelevantLinks(items) {
  var myGroserLink = '';
  var jayaGrocerLink = '';
  var lotussLink = '';
  
  for (var i = 0; i < items.length; i++) {
    var link = items[i].link;
    
    if (link.includes('mygroser') && !myGroserLink && !link.includes('termsandcondition')) {
      myGroserLink = link;
    }
    
    if (link.includes('jayagrocer') && !jayaGrocerLink) {
      jayaGrocerLink = link;
    }
    
    if (link.includes('lotuss') && !lotussLink) {
      lotussLink = link;
    }
    
    if (myGroserLink && jayaGrocerLink && lotussLink) {
      break;
    }
  }
  
  return {
    myGroserLink: myGroserLink,
    jayaGrocerLink: jayaGrocerLink,
    lotussLink: lotussLink
  };
}

function generateShopeeLink(preference) {
  var url = '';
  if (preference === 'Dried Food') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119122590';
  } else if (preference === 'Staple Food & Biscuits') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119122307';
  } else if (preference === 'Beverage') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119121687';
  } else if (preference === 'Spices') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119122507';
  } else if (preference === 'Instant Noodle & Canned Food') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119121843';
  } else if (preference === 'Cake Mixed') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119122549';
  } else if (preference === 'Household Essentials') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119123009';
  } else if (preference === 'Personal Care') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119127169';
  } else if (preference === 'Pet food') {
    url = 'https://shopee.com.my/lumchuan?page=0&shopCollection=119127194';
  }
  
  return url;
}

function generateLazadaLink(preference) {
  var url = '';
  if (preference === 'Dried Food') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbl26k3y&q=All-Products&shop_category_ids=1034130&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Staple Food & Biscuits') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbesgOch&q=All-Products&shop_category_ids=1034132&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Beverage') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbpx95OE&q=All-Products&shop_category_ids=1034134&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Spices') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbSFmwDk&q=All-Products&shop_category_ids=1034131&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Instant Noodle & Canned Food') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbrxi6gG&q=All-Products&shop_category_ids=1034133&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Cake Mixed') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbqJhWjf&q=All-Products&shop_category_ids=1034135&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Household Essentials') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbQoq2d0&q=All-Products&shop_category_ids=1034136&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Personal Care') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bbeYBq8q&q=All-Products&shop_category_ids=1034137&from=wangpu&sc=KVUG&shopId=1734801';
  } else if (preference === 'Pet food') {
    url = 'https://www.lazada.com.my/lum-chuan-sdn-bhd/?spm=a2o4k.10415192.0.0.39f668bblePMak&q=All-Products&shop_category_ids=1034138&from=wangpu&sc=KVUG&shopId=1734801';
  }
  
  return url;
}

function updateCampaignTracker(sheet, rowIndex, links) {
  if (links.myGroserLink) {
    sheet.getRange(rowIndex, 8).setValue(links.myGroserLink);  // Column H (8th column)
  }
  if (links.jayaGrocerLink) {
    sheet.getRange(rowIndex, 9).setValue(links.jayaGrocerLink);  // Column I (9th column)
  }
  if (links.lotussLink) {
    sheet.getRange(rowIndex, 10).setValue(links.lotussLink); // Column J (10th column)
  }
  if (links.shopeeLink) {
    sheet.getRange(rowIndex, 11).setValue(links.shopeeLink); // Column K (11th column)
  }
  if (links.lazadaLink) {
    sheet.getRange(rowIndex, 12).setValue(links.lazadaLink); // Column L (12th column)
  }
}
