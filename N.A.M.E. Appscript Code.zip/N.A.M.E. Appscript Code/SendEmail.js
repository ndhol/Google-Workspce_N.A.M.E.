function sendAutomatedEmails() {
  var spreadsheetId = '1pck0zyibpzJ-_0SBGa0-LQ0L7pI9-9eSUzOnXo3wWGY'; // Replace with your spreadsheet ID
  var spreadsheet = SpreadsheetApp.openById(spreadsheetId);

  // Fetch customer data from the Customer sheet
  var customerSheet = spreadsheet.getSheetByName('Customer');
  if (!customerSheet) {
    Logger.log('Customer sheet not found.');
    return;
  }
  var customerData = customerSheet.getDataRange().getValues();

  // Fetch campaign data from the Campaign sheet
  var campaignSheet = spreadsheet.getSheetByName('Campaign');
  if (!campaignSheet) {
    Logger.log('Campaign sheet not found.');
    return;
  }
  var campaignData = campaignSheet.getDataRange().getValues();

  // Fetch the email template from Google Docs
  var templateId = '1DlRORrsxk5iePhMyhq0vTkG97s-jBYyPKLeSA0GfTXI'; // Replace with your Google Docs document ID
  var template = fetchTemplate(templateId);
  
  if (!template) {
    Logger.log('Failed to fetch or parse template.');
    return;
  }

  // Fetch image data from the Images sheet
  var imagesSheet = spreadsheet.getSheetByName('Images');
  if (!imagesSheet) {
    Logger.log('Images sheet not found.');
    return;
  }
  var imagesData = imagesSheet.getDataRange().getValues();
  var imagesMap = createImagesMap(imagesData);

  // Loop through each customer in the Customer sheet
  for (var i = 1; i < customerData.length; i++) {
    var customerName = customerData[i][1]; // Name
    var email = customerData[i][4]; // Email
    var preferences = customerData[i][5] ? customerData[i][5].split(',') : []; // Preferences (split by comma)
    var categoryLinks = customerData[i].slice(7, 12).map(function(links) {
      return links.split(',');
    }); // Fetch category links from columns 7 to 11 and split by comma

    var emailContent = '';

    // Add Body1 (formerly Greeting) once at the beginning
    var body1 = template.body1
      .replace(/{{CustomerName}}/g, customerName || 'Valued Customer')
      .replace(/{{PreferenceCategory}}/g, preferences.join(', '));
    
    emailContent += body1;

    for (var j = 0; j < preferences.length; j++) {
      var preferenceCategory = preferences[j] ? preferences[j].trim() : '';
      var campaignDetails = findCampaignDetails(preferenceCategory, campaignData);
      var promotionDetails = 'Special discount just for you!';
      var productBenefit1 = 'Big Savings!';
      var productBenefit2 = 'Quality Assurance!';
      var storeName = 'Lum Chuan'; // Static store name or fetch from sheet if available
      var categoryImageUrl = imagesMap[preferenceCategory] || 'https://example.com/path/to/default-image.jpg'; // Fetch image URL from map
      var unsubscribeLink = 'https://example.com/unsubscribe'; // Ensure this is the correct URL
      var trackingPixel = createTrackingPixel(customerData[i][0]);

      // Personalize the email content with multiple replacements for Body2 (formerly Body1)
      var body2 = template.body2
        .replace(/{{CustomerName}}/g, customerName || 'Valued Customer')
        .replace(/{{PreferenceCategory}}/g, preferenceCategory || 'Our Products')
        .replace(/{{CampaignName}}/g, campaignDetails.name || 'Latest Campaign')
        .replace(/{{ProductName}}/g, campaignDetails.productName || 'Featured Product')
        .replace(/{{PromotionDetails}}/g, promotionDetails)
        .replace(/{{ProductBenefit1}}/g, productBenefit1)
        .replace(/{{ProductBenefit2}}/g, productBenefit2)
        .replace(/{{StartDate}}/g, campaignDetails.startDate)
        .replace(/{{EndDate}}/g, campaignDetails.endDate)
        .replace(/{{StoreName}}/g, storeName)
        .replace(/{{CategoryImage}}/g, '<img src="' + categoryImageUrl + '" alt="Category Image" style="width:300px;height:auto;">')
        .replace(/{{unsubscribe}}/g, unsubscribeLink) // Ensure the unsubscribe link is replaced correctly
        .replace(/{{trackingPixel}}/g, trackingPixel)
        .replace(/{{CategoryLink1}}/g, categoryLinks[0][j] || '#')
        .replace(/{{CategoryLink2}}/g, categoryLinks[1][j] || '#')
        .replace(/{{CategoryLink3}}/g, categoryLinks[2][j] || '#')
        .replace(/{{CategoryLink4}}/g, categoryLinks[3][j] || '#')
        .replace(/{{CategoryLink5}}/g, categoryLinks[4][j] || '#');

      emailContent += body2;
    }

    // Add Body3 (formerly Body2) once at the end of the email
    emailContent += template.body3
      .replace(/{{StoreName}}/g, storeName)
      .replace(/{{unsubscribe}}/g, unsubscribeLink)
      .replace(/{{trackingPixel}}/g, trackingPixel);

    try {
      // Send the personalized email
      MailApp.sendEmail({
        to: email,
        subject: customerName + ', check out our special offers on ' + preferences.join(', ') + '!',
        htmlBody: emailContent
      });
      logEmailStatus(email, 'Sent');
    } catch (e) {
      logEmailStatus(email, 'Failed: ' + e.message);
    }
  }
}

function findCampaignDetails(preferenceCategory, campaignData) {
  for (var i = 1; i < campaignData.length; i++) {
    if (campaignData[i][4] == preferenceCategory) { // Assuming Product Category is in the fifth column
      return {
        name: campaignData[i][1], // Campaign Name
        startDate: campaignData[i][6], // Campaign Start Date
        endDate: campaignData[i][7], // Campaign End Date
        productName: campaignData[i][3] // Assuming Product Name is in the fourth column
      };
    }
  }
  return {
    name: 'Campaign Name Not Found',
    startDate: 'Start Date Not Found',
    endDate: 'End Date Not Found',
    productName: 'Product Name Not Found'
  };
}

function logEmailStatus(email, status) {
  var spreadsheetId = '1pck0zyibpzJ-_0SBGa0-LQ0L7pI9-9eSUzOnXo3wWGY'; // Replace with your spreadsheet ID
  var spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  var logSheet = spreadsheet.getSheetByName('Email Analysis');
  if (!logSheet) {
    Logger.log('Email Analysis sheet not found.');
    return;
  }
  logSheet.appendRow([new Date(), email, status]);
}

function fetchTemplate(templateId) {
  try {
    var doc = DocumentApp.openById(templateId);
    var body = doc.getBody().getText();

    // Extract Body1 (formerly Greeting), Body2 (formerly Body1), and Body3 (formerly Body2)
    var body1StartIndex = body.indexOf("Body1:") + "Body1:".length;
    var body2StartIndex = body.indexOf("Body2:") + "Body2:".length;
    var body3StartIndex = body.indexOf("Body3:") + "Body3:".length;

    if (body1StartIndex < 0 || body2StartIndex < 0 || body3StartIndex < 0) {
      throw new Error("One or more required sections ('Body1:', 'Body2:', 'Body3:') are missing in the template.");
    }

    var body1 = body.substring(body1StartIndex, body2StartIndex - "Body2:".length).trim();
    var body2 = body.substring(body2StartIndex, body3StartIndex - "Body3:".length).trim();
    var body3 = body.substring(body3StartIndex).trim();

    return {
      body1: body1,
      body2: body2,
      body3: body3
    };
  } catch (e) {
    Logger.log('Failed to fetch template: ' + e.message);
    return null;
  }
}

function createTrackingPixel(customerId) {
  var trackingUrl = 'https://www.example.com/track?customerId=' + customerId + '&utm_source=email&utm_medium=tracking_pixel';
  return '<img src="' + trackingUrl + '" width="1" height="1" style="display:none;">';
}

function doGet(e) {
  var customerId = e.parameter.customerId || 'unknown';
  var utmSource = e.parameter.utm_source || 'unknown';
  var utmMedium = e.parameter.utm_medium || 'unknown';
  var utmCampaign = e.parameter.utm_campaign || 'unknown';
  var utmTerm = e.parameter.utm_term || 'unknown';

  var spreadsheetId = '1pck0zyibpzJ-_0SBGa0-LQ0L7pI9-9eSUzOnXo3wWGY'; // Replace with your spreadsheet ID
  var spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  var logSheet = spreadsheet.getSheetByName('TrackingLog');
  if (!logSheet) {
    logSheet = spreadsheet.insertSheet('TrackingLog');
    logSheet.appendRow(['Timestamp', 'Customer ID', 'UTM Source', 'UTM Medium', 'UTM Campaign', 'UTM Term']);
  }

  logSheet.appendRow([new Date(), customerId, utmSource, utmMedium, utmCampaign, utmTerm]);

  return HtmlService.createHtmlOutput('Thank you for your interest!');
}

function createImagesMap(imagesData) {
  var imagesMap = {};
  for (var i = 1; i < imagesData.length; i++) {
    var category = imagesData[i][0]; // Category
    var imageUrl = imagesData[i][1]; // Image URL
    imagesMap[category] = imageUrl;
  }
  return imagesMap;
}
